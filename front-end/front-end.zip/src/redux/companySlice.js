import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import companyService from "../services/companyService";

export const getCompanyList = createAsyncThunk(
  "/get-company-list",
  async () => {
    try {
      const response = await companyService.getCompanyList();
      const data = await response.data;
      return data;
    } catch (error) {
      return error.response.data;
    }
  }
);

export const getCompanyReviews = createAsyncThunk(
  "/get-company-review",
  async (company_id) => {
    try {
      const response = await companyService.getCompanyReviews(company_id);
      const data = await response.data;
      return data;
    } catch (error) {
      return error.response.data;
    }
  }
);

export const addReviewDetails = createAsyncThunk(
  "/add-review",
  async (reviewData) => {
    try {
      const response = await companyService.addReviewDetails(reviewData);
      const data = await response.data;
      return data;
    } catch (error) {
      return error.response.data;
    }
  }
);

export const getCompanyData = createAsyncThunk(
  "/get-company-data",
  async (company_id) => {
    try {
      const response = await companyService.getCompanyData(company_id);
      const data = await response.data;
      return data;
    } catch (error) {
      return error.response.data;
    }
  }
);

export const addCompanyDetails = createAsyncThunk(
  "/add-company-details",
  async (uploadData) => {
    try {
      const response = await companyService.addCompnayDetails(uploadData);
      const data = await response.data;
      return data;
    } catch (error) {
      return error.response.data;
    }
  }
);

export const signup = createAsyncThunk(
  "/add-signup-details",
  async (signupData) => {
    try {
      const response = await companyService.signup(signupData);
      const data = await response.data;
      return data;
    } catch (error) {
      return error.response.data;
    }
  }
);

export const login = createAsyncThunk(
  "/add-signup-details",
  async (loginData) => {
    try {
      const response = await companyService.login(loginData);
      const data = await response.data;
      return data;
    } catch (error) {
      return error.response.data;
    }
  }
);

export const companyReducer = createSlice({
  name: "company",
  initialState: {
    loading: false,
    error: null,
    searchResult: "",
    companyList: [],
    companyReviews: [],
  },
  reducers: {
    searchBar: (state, action) => {
      state.searchResult = action.payload;
    },
  },

  extraReducers: (builder) => {
    builder.addCase(getCompanyList.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getCompanyList.fulfilled, (state, action) => {
      state.loading = false;
      state.companyList = action?.payload?.data;
    });
    builder.addCase(getCompanyList.rejected, (state, action) => {
      state.loading = false;
    });

    builder.addCase(getCompanyReviews.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getCompanyReviews.fulfilled, (state, action) => {
      state.loading = false;
      state.companyReviews = action?.payload?.data;
    });
    builder.addCase(getCompanyReviews.rejected, (state, action) => {
      state.loading = false;
    });

  },
});

export const { searchBar } = companyReducer.actions;

export default companyReducer.reducer;

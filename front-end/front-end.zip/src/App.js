import './App.css';
import { Routes, Route } from "react-router-dom";
import Layout from './containers/Layout';
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
    <div className="App">
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
      <Routes>
        {/* <Route path="/admin/*" element={<AdminLayout />} /> */}
        {/* <Route path="/auth/*" element={<SignupLayout />} /> */}
        <Route path="*" element={<Layout />} />
      </Routes>
    </div>
  );
}

export default App;

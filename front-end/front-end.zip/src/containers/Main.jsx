import React from "react";
import { Route, Routes } from "react-router-dom";
import Home from "../pages/Home/Home";
import PageNotFound from "../pages/PageNotFound";
import CompanyReview from "../pages/CompanyReview/CompanyReview"
import DashBoard from "../pages/DashBoard/DashBoard";
import Signup from "../pages/Signup/Signup";
import Login from "../pages/Login/Login";

const Main = (props) => {
  return (
    <main>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/sign-up" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        {/* <Route path="/home" element={<Home />} /> */}
        <Route path="/review/:company_id" element={<CompanyReview />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </main>
  );
};

export default Main;

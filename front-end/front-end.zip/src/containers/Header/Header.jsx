import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import { HeaderStyle } from "./style"
import ReviewLogo from "../../assets/images/review-logo.png";
import {searchBar} from "../../redux/companySlice";
import { useDispatch, useSelector } from "react-redux";

const Header = () => {
    const count = useSelector((state) => state?.company?.searchResult
    )
    console.log('count: ', count)
    const dispatch = useDispatch();
    const [search, setSearch] = useState();
    const handleSearch = ()=> {
        console.log("search", search);
        dispatch(searchBar(search));
    }
    return (
        <>
            <HeaderStyle>
                <nav className="navbar sticky-top navbar-expand-lg navbar-light bg-light">
                    <div className="container">
                        <Link className="navbar-brand" to="/">
                            <img src={ReviewLogo} alt="review-logo" className='review-logo' />
                        </Link>
                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <div className="d-flex col-sm-4 col-md-3">
                                <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search"
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value)}
                                />
                                <button className="btn btn-outline-success" type='button' onClick={handleSearch}>Search</button>
                            </div>
                            <ul className="navbar-nav mb-2 mb-lg-0">
                                <li className="nav-item">
                                    <Link className="nav-link active" aria-current="page" to={"/sign-up"}>SignUp</Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link" to="/login">Login</Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </HeaderStyle>
        </>
    )
}

export default Header
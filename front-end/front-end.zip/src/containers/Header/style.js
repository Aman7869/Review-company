import styled from 'styled-components';

export const HeaderStyle = styled.p`
  & .navbar-collapse{
    position: relative;
    left: 52%;
  } 

  & .review-logo {
    width: 152px;
    mix-blend-mode: darken;
  }
`;

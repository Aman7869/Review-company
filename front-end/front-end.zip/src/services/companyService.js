import ApiService from "./ApiService";

export default class applyNowService {
  static getCompanyList = () =>
    ApiService.get("/get-company-listing");

  // static getCountryPhoneCodeListing = () =>
  //   ApiService.get("/common/get-country-phone-code-listing");

  static getCompanyReviews = (cid) =>
    ApiService.get(`/get-company-reviews/${cid}`);

  static addReviewDetails = (data) =>
    ApiService.post(`/add-reviews`, data);

  static getCompanyData = (cid) =>
    ApiService.get(`/get-company-data/${cid}`);

  static addCompnayDetails = (data) =>
    ApiService.post("/add-company", data);

  static signup = (signupData) =>
    ApiService.post("/sign-up", signupData);

  static login = (loginData) =>
    ApiService.post("/login", loginData);

  static deleteMember = (data) => ApiService.put("/front/delete-member", data);

  static getTotalAmount = (data) =>
    ApiService.post("/front/get-total-amount", data);
}

export const calculateTotalSumOfAverageRatings = (reviews) => {
    const userRatings = {};

    // Group ratings by user
    reviews.forEach(review => {
        const { full_name, rating } = review;
        if (!userRatings[full_name]) {
            userRatings[full_name] = [];
        }
        userRatings[full_name].push(rating);
    });

    // Calculate average rating for each user and sum the averages
    let totalSumOfAverageRatings = 0;
    for (const user in userRatings) {
        const ratings = userRatings[user];
        const sum = ratings.reduce((acc, rating) => acc + rating, 0);
        const average = sum / ratings.length;
        totalSumOfAverageRatings += average;
    }

    return totalSumOfAverageRatings.toFixed(2); // Return the sum rounded to 2 decimal places
};
import React from 'react'
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Button, Form } from 'react-bootstrap';
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";
import { LoginStyle } from "./style";
import { login } from "../../redux/companySlice";
import { useNavigate } from "react-router-dom";

const Login = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const formik = useFormik({
        initialValues: {
            userName: '',
            password: '',
        },
        validationSchema: Yup.object({
            userName: Yup.string().required('Required'),
            password: Yup.string()
                .required('Please enter password.')
                .min(8, 'Password is too short - should be 8 chars minimum.')
        }),
        onSubmit: (values) => {

            const data = {
                userName: values?.userName,
                password: values?.password,
            }
            dispatch(login(data))
                .unwrap()
                .then((res) => {
                    formik.resetForm();
                    if (res.status === 1) {
                        toast.success(`${res.message}`, {
                            className: "toast-message",
                        });
                        navigate("/login");
                    }
                });
        },
    });
    return (
        <>
            <div className="container">
                <LoginStyle>
                    <Form onSubmit={formik.handleSubmit}>
                        <Form.Group controlId="userName">
                            User Name <span style={{ color: 'red' }}>*</span>
                            <Form.Control
                                type="text"
                                placeholder="Enter user name"
                                {...formik.getFieldProps('userName')}
                                isInvalid={formik.touched.userName && formik.errors.userName}
                            />
                            <Form.Control.Feedback type="invalid">
                                {formik.errors.userName}
                            </Form.Control.Feedback>
                        </Form.Group>

                        <Form.Group controlId="password" className='pt-4'>
                            Password <span style={{ color: 'red' }}>*</span>
                            <Form.Control
                                type="password"
                                placeholder="Enter Password"
                                {...formik.getFieldProps('password')}
                                isInvalid={formik.touched.password && formik.errors.password}
                            />
                            <Form.Control.Feedback type="invalid">
                                {formik.errors.password}
                            </Form.Control.Feedback>
                        </Form.Group>

                        <Button variant="primary" type="submit" className='login-btn mt-3'>
                            Save
                        </Button>
                    </Form>
                </LoginStyle>
            </div>
        </>
    )
}

export default Login
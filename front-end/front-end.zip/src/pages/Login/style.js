import styled from "styled-components";

export const LoginStyle = styled.div`
text-align: left;

& .login-btn {
    width: 25%;
    display: block;
    margin: 0 auto;
}
`;
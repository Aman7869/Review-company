import React from 'react'
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Button, Form } from 'react-bootstrap';
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";
import { SignupStyle } from "./style";
import { signup } from "../../redux/companySlice";
import { useNavigate } from "react-router-dom";

const Signup = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const formik = useFormik({
        initialValues: {
            userName: '',
            dob: '',
            phoneNumber: '',
            city: '',
            userImage: "",
        },
        validationSchema: Yup.object({
            userName: Yup.string().required('Required'),
            dob: Yup.date().required('Required'),
            phoneNumber: Yup.number().required('Required'),
            city: Yup.string().required('Required'),
            userImage: Yup.mixed()
                .required('A file is required')
                .test(
                    'fileSize',
                    'File size is too large',
                    value => value && value.size <= 2 * 1024 * 1024 // 2MB
                )
                .test(
                    'fileFormat',
                    'Unsupported file format',
                    value => value && ['image/jpg', 'image/jpeg', 'image/png'].includes(value.type)
                ),
        }),
        onSubmit: (values) => {

            const data = new FormData();
            data.append("userName", values.userName);
            data.append("dob", values.dob);
            data.append("phoneNumber", values.phoneNumber);
            data.append("city", values.city);
            data.append("userImage", values.userImage);
            dispatch(signup(data))
                .unwrap()
                .then((res) => {
                    formik.resetForm();
                    if (res.status === 1) {
                        toast.success(`${res.message}`, {
                            className: "toast-message",
                        });
                        navigate("/login");
                    }
                });
        },
    });
    return (
        <>
            <div className="container">
                <SignupStyle>
                    <Form onSubmit={formik.handleSubmit}>
                        <Form.Group controlId="userName">
                            User Name <span style={{ color: 'red' }}>*</span>
                            <Form.Control
                                type="text"
                                placeholder="Enter user name"
                                {...formik.getFieldProps('userName')}
                                isInvalid={formik.touched.userName && formik.errors.userName}
                            />
                            <Form.Control.Feedback type="invalid">
                                {formik.errors.userName}
                            </Form.Control.Feedback>
                        </Form.Group>

                        <Form.Group controlId="dob" className='pt-4'>
                            Date of Birth <span style={{ color: 'red' }}>*</span>
                            <Form.Control
                                type="date"
                                placeholder="Enter Dob"
                                {...formik.getFieldProps('dob')}
                                isInvalid={formik.touched.dob && formik.errors.dob}
                            />
                            <Form.Control.Feedback type="invalid">
                                {formik.errors.dob}
                            </Form.Control.Feedback>
                        </Form.Group>

                        <Form.Group controlId="phoneNumber" className='pt-4'>
                            Phone Number <span style={{ color: 'red' }}>*</span>
                            <Form.Control
                                type="text"
                                placeholder="Enter Phone number"
                                maxLength={"10"}
                                {...formik.getFieldProps('phoneNumber')}
                                isInvalid={formik.touched.phoneNumber && formik.errors.phoneNumber}
                            />
                            <Form.Control.Feedback type="invalid">
                                {formik.errors.phoneNumber}
                            </Form.Control.Feedback>
                        </Form.Group>

                        <Form.Group controlId="city" className='pt-4'>
                            City <span style={{ color: 'red' }}>*</span>
                            <Form.Control
                                type="text"
                                placeholder="Enter city"
                                {...formik.getFieldProps('city')}
                                isInvalid={formik.touched.city && formik.errors.city}
                            />
                            <Form.Control.Feedback type="invalid">
                                {formik.errors.city}
                            </Form.Control.Feedback>
                        </Form.Group>

                        <Form.Group controlId="userImage" className='pt-4'>
                            User Image
                            <Form.Control
                                type="file"
                                name="userImage"
                                onChange={(event) =>
                                    formik.setFieldValue('userImage', event.currentTarget.files[0])
                                }
                            />
                            <Form.Control.Feedback type="invalid">
                                {formik.errors.userImage}
                            </Form.Control.Feedback>
                        </Form.Group>

                        <Button variant="primary" type="submit" className='sign-btn mt-3'>
                            Save
                        </Button>
                    </Form>
                </SignupStyle>
            </div>
        </>
    )
}

export default Signup
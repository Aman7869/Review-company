import styled from "styled-components";

export const SignupStyle = styled.div`
    text-align: left;

    & .sign-btn {
        width: 25%;
        display: block;
        margin: 0 auto;
    }
`;
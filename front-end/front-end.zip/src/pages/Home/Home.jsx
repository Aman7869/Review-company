import React, { useEffect, useState } from 'react';
import FilterComponent from '../../Components/FilterComponent/FilterComponent';
import CompanyListComponent from '../../Components/CompanyList/CompanyList';
import { useDispatch, useSelector } from "react-redux";
import { getCompanyList } from "../../redux/companySlice"
import { toast } from "react-toastify";


const Home = () => {
    const dispatch = useDispatch();
    
    const [sortCriterion, setSortCriterion] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResult, setSearchResult] = useState('');
    const [filteredCompanies, setFilteredCompanies] = useState([]);
    const CompanyList = useSelector(
        (state) => state?.company?.companyList
    );

    const searchFilter = useSelector((state) => state?.company?.searchResult)
    useEffect(()=> {
        setSearchQuery(searchFilter.toLowerCase());
    },[searchFilter])

    console.log("CountryList", CompanyList);


    useEffect(() => {
        dispatch(getCompanyList())
            .unwrap()
            .then((res) => {
                if (res.status === 401) {
                    toast.error(`${res?.message}`, {
                        className: "toast-message",
                    });
                }
            });
    }, [dispatch]);

    useEffect(() => {
        let updatedList = CompanyList;

        if (searchQuery) {
            updatedList = updatedList.filter(company =>
                company.company_name.toLowerCase().includes(searchQuery.toLowerCase())
            );
        }

        if (sortCriterion === 'name') {
            updatedList = [...updatedList].sort((a, b) => a.company_name.localeCompare(b.company_name));
        } else if (sortCriterion === 'city') {
            updatedList = [...updatedList].sort((a, b) => a.location.localeCompare(b.location));
        }

        setFilteredCompanies(updatedList);
    }, [searchQuery, sortCriterion, CompanyList]);

    const handleSearchChange = (e) => {
        setSearchResult(e.target.value);
    };

    const handleFindCompany = (result) => {
        setSearchQuery(result);
    };

    const handleSortChange = (e) => {
        setSortCriterion(e.target.value);
    };

    return (
        <>
            <div className='container'>
                <div>
                    <FilterComponent
                        searchResult={searchResult}
                        handleSearchChange={handleSearchChange}
                        handleFindCompany={handleFindCompany}
                        handleSortChange={handleSortChange}
                    />
                </div>
                <div className='company-list-section pt-5'>
                    {filteredCompanies && filteredCompanies.map((item) => (
                        <CompanyListComponent key={item.id} item={item} cid={item?.id} />
                    ))}
                </div>
            </div>
        </>
    )
}

export default Home
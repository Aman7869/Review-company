import styled from "styled-components";
export const CompanyPageStyle = styled.div`
    & .container-review-section{
    box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }

    & .count-review{
    text-align: left;
    }
`;
import React, { useEffect, useState } from 'react';
import { useParams } from "react-router-dom";
import CompanyReviews from '../../Components/CompanyReviews/CompanyReviews';
import ReviewsComponent from '../../Components/ReviewsComponent/ReviewsComponent';
import { CompanyPageStyle } from "./style"
import { getCompanyReviews, getCompanyData } from "../../redux/companySlice"
import { toast } from "react-toastify";
import { useDispatch, useSelector } from "react-redux";
import {calculateTotalSumOfAverageRatings} from "../../utility/common"

const CompanyReview = () => {
    const dispatch = useDispatch();
    const { company_id } = useParams();
    const companyReviews = useSelector(
        (state) => state?.company?.companyReviews
    );
    console.log("companyReviews", companyReviews);
    const userRatings = {};
    const averageRatings = {};
    const [companyData, setCompanyData] = useState();

   
    const result = calculateTotalSumOfAverageRatings(companyReviews);
    const totalSumOfAverageRatings = (result/companyReviews.length).toFixed(1);

    useEffect(() => {
        dispatch(getCompanyData(company_id))
            .unwrap()
            .then((res) => {
                if (res.status === 401) {
                    toast.error(`${res?.message}`, {
                        className: "toast-message",
                    });
                } else if (res?.data) {
                    setCompanyData(res?.data);
                    console.log("res?.data", res?.data)
                }
            });
    }, [dispatch]);

    useEffect(() => {
        dispatch(getCompanyReviews(company_id))
            .unwrap()
            .then((res) => {
                if (res.status === 401) {
                    toast.error(`${res?.message}`, {
                        className: "toast-message",
                    });
                }
            });
    }, [dispatch]);
    return (
        <>
            <CompanyPageStyle>
                <div className='container container-review-section'>
                    <div className='company-profile'>
                        <CompanyReviews data={companyData} avrRating = {totalSumOfAverageRatings} />
                    </div>

                    <div className='review-section pt-5'>
                        <p className='count-review ps-5'>Result Found: {companyReviews?.length}</p>
                        {
                            companyReviews && companyReviews?.map((item) =>
                                <ReviewsComponent item={item} key={item?.id} />)
                        }
                    </div>

                </div>
            </CompanyPageStyle>
        </>
    )
}

export default CompanyReview
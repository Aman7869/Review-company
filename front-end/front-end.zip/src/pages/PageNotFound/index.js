import PageNotFound from './PageNotFound';

export default PageNotFound;

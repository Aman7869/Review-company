import React, { useState } from 'react'
import { MenuListStyle } from './style';
import CompanyLogo from "../../assets/images/company.png";
import AddReviewModal from '../Modals/AddReviewModal';


const CompanyReviews = ({ data, avrRating }) => {
   
    const [showModal, setShowModal] = useState(false);

    const handleShow = () => setShowModal(true);
    const handleClose = () => setShowModal(false);
  
    const handleSave = (reviewDetails) => {
      console.log(reviewDetails);
      handleClose();
    };
    return (
        <>
            <MenuListStyle>
                <div className='restaurant-list pt-2 container'>
                    <div className='row'>
                        <div className='col-md-9'>
                            <div className="row">
                                <div className="col-md-2">
                                <img src={process.env.REACT_APP_UPLOAD_IMAGE_PATH+data?.company_logo} alt="company-logo" className='company-logo' />
                                </div>

                                <div className="col-md-4">
                                <p className='menu-list'>{data?.company_name}</p>
                                    <p className='price'>Location : {data?.location}</p>
                                    <p className='description pt-2' style={{fontWeight:"600"}}>{avrRating !== "NaN" ? avrRating : 0} </p>
                                </div>
                            </div>
                        </div>
                        <div className='col-md-3 right-section'>
                        <p className='text-center'>Founded on {data?.founded_on}</p>
                        <div className='menu-item'>
                                <button className='btn btn-dark me-4 mt-1 d-block w-100' onClick={handleShow}>Add Reviews</button>
                            </div>
                        </div>
                    </div>
                </div>
                <hr />
            </MenuListStyle>
            <AddReviewModal show={showModal} handleClose={handleClose} handleSave={handleSave} company_id = {data?.id} />
        </>
    )
}

export default CompanyReviews
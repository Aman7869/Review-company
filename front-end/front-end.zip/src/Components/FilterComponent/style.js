import styled from "styled-components";

export const FilterStyle = styled.div`
    & .filter-label{
    text-align : left;
    }  
    
    & .custom-btn{
        background-color: #7b0ad5;
        color: #fff;
    }

    & .seach-field {
        position: relative;
    }

    & .location-icon{
        position: absolute;
          width: 34px;
    height: 28px;
    top: 4px;
    right: 12px;
    }
`;
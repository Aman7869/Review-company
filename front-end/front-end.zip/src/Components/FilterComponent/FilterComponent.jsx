import React, { useState } from 'react'
import { FilterStyle } from "./style";
import AddCompanyModal from '../Modals/AddCompanyModal';
import locationIcon from "../../assets/images/location.png";


const FilterComponent = ({ handleSortChange, searchResult, handleSearchChange, handleFindCompany }) => {
    const [showModal, setShowModal] = useState(false);

    const handleShow = () => setShowModal(true);
    const handleClose = () => setShowModal(false);

    const handleSave = (companyDetails) => {
        handleClose();
    };
    return (
        <>
            <FilterStyle>
                <div className="row">
                    <div className="col-md-6">
                        <div className="row">
                            <label htmlFor="exampleInputEmail1" className='filter-label'>Find Company</label>
                            <div className="form-group col-md-8 seach-field">
                                <input
                                    type="text"
                                    className="form-control"
                                    id="cityInput"
                                    aria-describedby="emailHelp"
                                    placeholder="Find Company"
                                    value={searchResult}
                                    onChange={handleSearchChange}
                                />
                                <img src={locationIcon} alt="icon" className='location-icon' />
                            </div>
                            <div className="col-md-4">
                                <button type="submit" className="btn custom-btn" onClick={()=>handleFindCompany(searchResult)}>Find Company</button>
                            </div>

                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="row justify-content-end">
                            <label for="exampleInputEmail1" className='filter-label'>
                                &#160;</label>
                            <div className="col-md-4">
                                <button type="submit" className="btn custom-btn" onClick={handleShow}>Add Company</button>
                            </div>
                            <div className="form-group col-md-4">
                                <select className="form-control" id="exampleSelect" onChange={handleSortChange}>
                                    <option value="">Select</option>
                                    <option value="name">Name</option>
                                    <option value="city">City</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </FilterStyle>
            <AddCompanyModal show={showModal} handleClose={handleClose} handleSave={handleSave} />
        </>
    )
}

export default FilterComponent
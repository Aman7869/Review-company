import React from 'react'
import { ReviewStyle } from './style';
import CompanyLogo from "../../assets/images/company.png";
import moment from 'moment';


const StarRating = ({ count, starCount }) => {
    const stars = [];
    for (let i = starCount; i < 5; i++) {
        stars.push(<span key={i} className="fa fa-star"></span>);
    }

    return <>{stars}</>;
};
const ReviewsComponent = ({ item }) => {
    if (item?.rating < 5) {
        const count = 5 - item?.rating;
        const stars = [];

        for (let i = 0; i < count; i++) {
            stars.push(<span key={i} className="fa fa-star"></span>);
        }
    }
    return (
        <>
            <ReviewStyle>
                <div className='restaurant-list pt-2 container'>
                    <div className='row'>
                        <div className='col-md-12'>
                            <div className="row">
                                <div className="col-md-2">
                                    <img src={CompanyLogo} alt="company-logo" className='company-logo' />
                                </div>
                                <div className="col-md-10">
                                    <div className="row justify-content-between">
                                        <div className="col-md-4">
                                            <p className='menu-list'>{item?.full_name}</p>
                                            <p className='price'>{moment(item?.create_ts).format('DD-MM-YYYY')}</p>
                                        </div>
                                        <div className="col-md-4">
                                            <div className='text-end'>

                                                    {Array.from({ length: item?.rating }, (_, i) => (
                                                        <span key={i} className="fa fa-star checked"></span>
                                                    ))}
                                                    {
                                                        item?.rating < 5 && <StarRating count={5} starCount={item?.rating} />
                                                    }
                                                {/* <span class="fa fa-star"></span> */}
                                                {/* <span class="fa fa-star"></span> */}
                                            </div>
                                        </div>
                                    </div>
                                    <p>
                                        {item?.review_content}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr />
            </ReviewStyle>
        </>
    )
}

export default ReviewsComponent
import styled from "styled-components";

export const ReviewStyle = styled.div`
        color: #616161;
        text-align: left;
        & .menu-list {
            font-weight: 700;
            font-size: 1.125rem;
            line-height: 1.75rem;
            color: #000;
            margin-bottom: 1px;
        }

        & .description,.price {
            margin-bottom: 1px;
        }
        & .description{
            font-size: 0.875rem;
        }

        & .company-logo {
            width: 107px;
            height: 100px;
        }
        

        & .right-section {
            position: relative;
        }

        & .menu-item {
        position : absolute;
        bottom: 0;
        width: 100%;
        }

        & .checked {
            color: orange;
            }

`;
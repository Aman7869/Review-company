import React, { useEffect, useState } from 'react';
import { MenuListStyle } from './style';
import { useNavigate } from 'react-router-dom';
import { getCompanyReviews } from "../../redux/companySlice";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { calculateTotalSumOfAverageRatings } from "../../utility/common";

const CompanyList = ({ item, cid }) => {
    console.log('item: ', item);
    // const companyReviews = useSelector(
    //     (state) => state?.company?.companyReviews
    // );
    // console.log('companyReviews: ', companyReviews);
    const [companyReview, setCompanyReview] = useState([])
    console.log('companyReview:useState ', companyReview);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const company_id = cid;

    const redirectReview = (cid) => {
        navigate('/review/' + cid);
    }

    let totalSumOfAverageRatings = 0;
    if (companyReview.length > 0) {

        const result = calculateTotalSumOfAverageRatings(companyReview);
        totalSumOfAverageRatings = (result / companyReview.length).toFixed(1);
    }

    useEffect(() => {
        if (company_id) {
            dispatch(getCompanyReviews(company_id))
                .unwrap()
                .then((res) => {
                    console.log("res", res);
                    setCompanyReview(res?.data);
                    if (res.status === 401) {
                        toast.error(`${res?.message}`, {
                            className: "toast-message",
                        });
                    }
                });
        }
    }, []);

    return (
        <>
            <MenuListStyle>
                <div className='restaurant-list pt-2 container'>
                    <div className='row'>
                        <div className='col-md-9'>
                            <div className="row">
                                <div className="col-md-2">
                                    <img src={process.env.REACT_APP_UPLOAD_IMAGE_PATH + item?.company_logo} alt="company-logo" className='company-logo' />
                                </div>

                                <div className="col-md-4">
                                    <p className='menu-list'>{item?.company_name}</p>
                                    <p className='price'>Location: {item?.location}</p>
                                    <p className='description pt-2' style={{ fontWeight: "600" }}>{totalSumOfAverageRatings}</p>
                                </div>
                            </div>
                        </div>
                        <div className='col-md-3 right-section'>
                            <p className='text-center'>Founded on {item?.founded_on}</p>
                            <div className='menu-item'>
                                <button className='btn btn-dark me-4 mt-1 d-block w-100' onClick={() => redirectReview(item?.id)}>Detail Review</button>
                            </div>
                        </div>
                    </div>
                </div>
                <hr />
            </MenuListStyle>
        </>
    );
}

export default CompanyList;

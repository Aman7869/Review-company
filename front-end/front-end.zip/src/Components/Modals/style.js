import styled from "styled-components";

export const ModalStyle = styled.div`
    .modal-btn{
    display: block;
    margin: 0 auto;
    width: 30%;
    }
`
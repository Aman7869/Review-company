import React from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { ModalStyle } from "./style";
import { toast } from "react-toastify";
import {addCompanyDetails} from "../../redux/companySlice"
import { useDispatch } from "react-redux";
import { getCompanyList } from "../../redux/companySlice"


const AddCompanyModal = ({ show, handleClose, handleSave }) => {
  const dispatch = useDispatch();
  const formik = useFormik({
    initialValues: {
      companyName: '',
      location: '',
      foundedOn: '',
      city: '',
      logo: "",
    },
    validationSchema: Yup.object({
      companyName: Yup.string().required('Required'),
      location: Yup.string().required('Required'),
      foundedOn: Yup.date().required('Required'),
      city: Yup.string().required('Required'),
    }),
    onSubmit: (values) => {

      const data = new FormData();
      data.append("companyName", values.companyName);
      data.append("location", values.location);
      data.append("foundedOn", values.foundedOn);
      data.append("city", values.city);
      data.append("companyLogo", values.logo);
      dispatch(addCompanyDetails(data))
      .unwrap()
      .then((res) => {
        formik.resetForm();
        if (res.status === 1) {
          toast.success(`${res.message}`, {
            className: "toast-message",
          });
          dispatch(getCompanyList());
          handleClose();
        }
      });
      // handleSave(values);
    },
  });

  const handleModalClose = () => {
    handleClose();
    formik.resetForm();
  };

  return (
    <Modal show={show} onHide={handleModalClose}>
      <ModalStyle>
        <Modal.Header closeButton>
          <Modal.Title>Add Company</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={formik.handleSubmit}>
            <Form.Group controlId="companyName">
              Company Name <span style={{ color: 'red' }}>*</span>
              <Form.Control
                type="text"
                placeholder="Enter company name"
                {...formik.getFieldProps('companyName')}
                isInvalid={formik.touched.companyName && formik.errors.companyName}
              />
              <Form.Control.Feedback type="invalid">
                {formik.errors.companyName}
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group controlId="location" className='pt-2'>
              Location <span style={{ color: 'red' }}>*</span>
              <Form.Control
                type="text"
                placeholder="Enter location"
                {...formik.getFieldProps('location')}
                isInvalid={formik.touched.location && formik.errors.location}
              />
              <Form.Control.Feedback type="invalid">
                {formik.errors.location}
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group controlId="foundedOn" className='pt-2'>
              Founded On <span style={{ color: 'red' }}>*</span>
              <Form.Control
                type="date"
                placeholder="Enter founding date"
                {...formik.getFieldProps('foundedOn')}
                isInvalid={formik.touched.foundedOn && formik.errors.foundedOn}
              />
              <Form.Control.Feedback type="invalid">
                {formik.errors.foundedOn}
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group controlId="city" className='pt-2'>
              City <span style={{ color: 'red' }}>*</span>
              <Form.Control
                type="text"
                placeholder="Enter city"
                {...formik.getFieldProps('city')}
                isInvalid={formik.touched.city && formik.errors.city}
              />
              <Form.Control.Feedback type="invalid">
                {formik.errors.city}
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group controlId="logo" className='pt-2'>
              Upload Logo
              <Form.Control
                type="file"
                name="logo"
                onChange={(event) =>
                  formik.setFieldValue('logo', event.currentTarget.files[0])
                }
              />
              <Form.Control.Feedback type="invalid">
                {formik.errors.logo}
              </Form.Control.Feedback>
            </Form.Group>

            <Button variant="primary" type="submit" className='modal-btn mt-3'>
              Save
            </Button>
          </Form>
        </Modal.Body>
      </ModalStyle>
    </Modal>
  );
};

export default AddCompanyModal;

import React from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { FaStar } from 'react-icons/fa';
import { ModalStyle } from "./style";
import { getCompanyReviews, addReviewDetails } from "../../redux/companySlice"
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";

const AddReviewModal = ({ show, handleClose, handleSave, company_id }) => {
  const dispatch = useDispatch();

  const formik = useFormik({
    initialValues: {
      fullName: '',
      subject: '',
      reviewText: '',
      rating: 0,
    },
    validationSchema: Yup.object({
      fullName: Yup.string().required('Required'),
      subject: Yup.string().required('Required'),
      reviewText: Yup.string().required('Required'),
      rating: Yup.number().required('Required').min(1, 'Rating must be at least 1'),
    }),
    onSubmit: (values) => {
      // handleSave(values);
      // formik.resetForm();
      const data = {
        fullName: values.fullName,
        subject: values.subject,
        reviewText: values.reviewText,
        rating: values.rating,
        cid: company_id
      }

      console.log("data", data);
      dispatch(addReviewDetails(data))
        .unwrap()
        .then((res) => {
          if (res.status === 200) {
            formik.resetForm();
            toast.success(`${res.message}`, {
              className: "toast-message",
            });
            dispatch(getCompanyReviews(company_id));
            handleClose();
          }
        });
    },
  });

  const handleModalClose = () => {
    handleClose();
    formik.resetForm();
  };

  return (
    <Modal show={show} onHide={handleModalClose}>
      <ModalStyle>
        <Modal.Header closeButton>
          <Modal.Title>Add Review</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={formik.handleSubmit}>
            <Form.Group controlId="fullName">
              <Form.Label>
                Full Name <span style={{ color: 'red' }}>*</span>
              </Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter your full name"
                {...formik.getFieldProps('fullName')}
                isInvalid={formik.touched.fullName && formik.errors.fullName}
              />
              <Form.Control.Feedback type="invalid">
                {formik.errors.fullName}
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group controlId="subject">
              <Form.Label>
                Subject <span style={{ color: 'red' }}>*</span>
              </Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter the subject"
                {...formik.getFieldProps('subject')}
                isInvalid={formik.touched.subject && formik.errors.subject}
              />
              <Form.Control.Feedback type="invalid">
                {formik.errors.subject}
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group controlId="reviewText">
              <Form.Label>
                Review <span style={{ color: 'red' }}>*</span>
              </Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Write your review"
                {...formik.getFieldProps('reviewText')}
                isInvalid={formik.touched.reviewText && formik.errors.reviewText}
              />
              <Form.Control.Feedback type="invalid">
                {formik.errors.reviewText}
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group controlId="rating">
              <Form.Label>
                Rating <span style={{ color: 'red' }}>*</span>
              </Form.Label>
              <div>
                {[...Array(5)].map((star, index) => {
                  const ratingValue = index + 1;
                  return (
                    <label key={index}>
                      <input
                        type="radio"
                        name="rating"
                        value={ratingValue}
                        onClick={() => formik.setFieldValue('rating', ratingValue)}
                        style={{ display: 'none' }}
                      />
                      <FaStar
                        color={ratingValue <= formik.values.rating ? '#ffc107' : '#e4e5e9'}
                        size={30}
                        style={{ cursor: 'pointer' }}
                      />
                    </label>
                  );
                })}
              </div>
              {formik.touched.rating && formik.errors.rating ? (
                <div style={{ color: 'red', fontSize: '0.8em' }}>{formik.errors.rating}</div>
              ) : null}
            </Form.Group>

            <Button variant="primary" type="submit" className='modal-btn'>
              Save
            </Button>
          </Form>
        </Modal.Body>
      </ModalStyle>
    </Modal>
  );
};

export default AddReviewModal;

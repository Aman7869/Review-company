const config = require("config");
const express = require("express");
const app = express();
const http = require("http");
const cors = require("cors");
require("dotenv").config();
const path = require('path');
const port = process.env.PORT || 5000;
const appRouter = require("./router.js");
// const commonServices = require("./front/commonServices");

app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(
    cors({
        origin: [
            "http://localhost:3000",
            "http://localhost:3001",
        ],
    })
);
app.use(express.urlencoded({ extended: false, parameterLimit: 100000 }));

// const appRouter = require("./router.js");

console.log(`NODE_ENV: ${process.env.NODE_ENV}`);
console.log(`app: ${app.get("env")}`);
// console.log(config.get("appName"));

app.get("/api", (req, res) => {
    res.send("Hello World!");
});

app.use("/api", appRouter);

//Development
const options = {};
http.createServer(options, app).listen(port, function () {
    console.log("Express server listening on port " + port);
});


const checkFileExists = (filePath) => {
  var fs = require("fs");
  console.log(filePath);
  if (fs.existsSync(filePath)) {
    return true;
  }
  return false;
};


const createDirStructure = async (targetDir) => {
  try {
    let fs = require("fs");
    let path = require("path");
    let sep = path.sep;
    let initDir = path.isAbsolute(targetDir) ? sep : "";
    targetDir.split(sep).reduce((parentDir, childDir) => {
      let curDir = path.resolve(parentDir, childDir);
      if (!fs.existsSync(curDir)) {
        fs.mkdirSync(curDir);
        fs.chmodSync(curDir, 0777);
      }
      return curDir;
    }, initDir);
  } catch (err) {
    return {
      status: 0,
      message: "Something went wrong.",
      result: err,
    };
  }
};

const uploadFiles = async (req, res, fileInfoObj) => {
  try {
    if (typeof fileInfoObj.fieldName !== "undefined") {
      let path = require("path");
      let multer = require("multer");
      let uploadFieldName = fileInfoObj.fieldName;
      let prefixImg =
        typeof fileInfoObj.prefixImage !== "undefined"
          ? fileInfoObj.prefixImage + "_"
          : "";
      let rootPath =
        typeof fileInfoObj.rootPath !== "undefined"
          ? fileInfoObj.rootPath
          : path.join(__dirname, "../../");
      let publicPath =
        typeof fileInfoObj.publicPath !== "undefined"
          ? fileInfoObj.publicPath
          : "/";
      let uploadPath =
        typeof fileInfoObj.uploadPath !== "undefined"
          ? fileInfoObj.uploadPath
          : "uploads/docs";
      let filetypes =
        typeof fileInfoObj.allowedType !== "undefined"
          ? fileInfoObj.allowedType
          : /doc|docx|jpg|JPG|jpeg|JPEG|png|PNG|pdf|PDF/;
      let finalFilename = "";
      console.log("rootPath", rootPath);
      console.log("publicPath", publicPath);
      console.log("uploadPath", uploadPath);
      const storage = multer.diskStorage({
        destination: function (req, file, callback) {
          let uploadDir = "";
          if (file.fieldname == "companyLogo") {
            uploadDir = rootPath + publicPath + uploadPath;
          } else {
            uploadDir = rootPath + publicPath + uploadPath;
          }
          createDirStructure(uploadDir);
          console.log("file folder created")
          callback(null, uploadDir);
        },
        filename: function (req, file, callback) {
          console.log("prefix in common file", prefixImg);
          let filename = file?.originalname?.split(" ").join("");
          let fileExt = path.extname(file.originalname);
          finalFilename = `${prefixImg}${filename}`;
          callback(null, finalFilename);
        },
      });
      const fileFilter = (req, file, callback) => {
        const extname = filetypes.test(
          path.extname(file.originalname).toLowerCase()
        );
        const mimetype = filetypes.test(file.mimetype);
        if (mimetype && extname) {
          return callback(null, true);
        } else {
          callback("Unsupported File Format!");
        }
      };
      return multer({ storage: storage, fileFilter: fileFilter }).single(
        uploadFieldName
      );
    } else {
      return {
        status: 0,
        message: "Invalid file input!",
      };
    }
  } catch (err) {
    return {
      status: 0,
      message: "Something went wrong.",
      result: err,
    };
  }
};

module.exports = {

  checkFileExists,
  uploadFiles,
};

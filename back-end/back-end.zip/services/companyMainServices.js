const models = require("../models")
const commonServices = require("./commonServices");
const addCompany = async (req, res) => {
  try {
    let prefixImg = `${Date.now()}${Math.round(Math.random() * 1e9)}`;
    let upload = await commonServices.uploadFiles(req, res, {
      fieldName: "companyLogo",
      // uploadPath: "uploads/support-docs",
      uploadPath: "/uploads/company-logo/",
      publicPath: "back-end",
      prefixImage: prefixImg,
    });
    return new Promise(async (resolve, reject) => {
      return await upload(req, res, async function (err) {
        console.log('req: ', req);
        let data = req.body;
        let fileName = req?.file?.originalname;
        let finalFileName = prefixImg + "_" + fileName?.split(" ").join("");
        console.log("finalFileName", finalFileName);
        console.log("fileName", fileName);
        return await models.companyModel.create({
          company_name: data?.companyName,
          location: data?.location,
          founded_on: data?.foundedOn,
          city: data?.city,
          company_logo: finalFileName,
        })
          .then(async (applicationFormResult) => {
            if (applicationFormResult != null) {
              console.log('applicationFormResult: ', applicationFormResult);
              resolve({
                status: 1,
                message: "Record created successfully.",
                data: applicationFormResult,
              });
            }
          });
      });
    });
  } catch (error) {
    console.log("error", error);
    return {
      status: 0,
      message: "Something Went Wrong.",
      error: error.message,
    };
  }
};
const signUp = async (req, res) => {
  try {
    let prefixImg = `${Date.now()}${Math.round(Math.random() * 1e9)}`;
    let upload = await commonServices.uploadFiles(req, res, {
      fieldName: "userImage",
      // uploadPath: "uploads/support-docs",
      uploadPath: "/uploads/user/",
      publicPath: "back-end",
      prefixImage: prefixImg,
    });
    return new Promise(async (resolve, reject) => {
      return await upload(req, res, async function (err) {
        console.log('req: ', req);
        let data = req.body;
        let fileName = req?.file?.originalname;
        let finalFileName = prefixImg + "_" + fileName?.split(" ").join("");
        console.log("finalFileName", finalFileName);
        console.log("fileName", fileName);
        return await models.userModel.create({
          user_name: data?.userName,
          dob: data?.dob,
          phoneNumber: data?.phoneNumber,
          city: data?.city,
          user_image: finalFileName,
        })
          .then(async (signUpFormResult) => {
            if (signUpFormResult != null) {
              console.log('signUpFormResult: ', signUpFormResult);
              resolve({
                status: 1,
                message: "Record created successfully.",
              });
            }
          });
      });
    });
  } catch (error) {
    console.log("error", error);
    return {
      status: 0,
      message: "Something Went Wrong.",
      error: error.message,
    };
  }
};

const getCompanyList = async (req, res) => {
  try {
    return await models.companyModel
      .findAll({
        attributes: ["id", "company_name", "location", "founded_on", "company_logo"]
      })
      .then(async (companyList) => {
        return {
          status: 200,
          message: "Company List.",
          data: companyList,
        };
      })
      .catch((error) => {
        return {
          status: 401,
          message: "Something Went Wrong.",
          error: error.message,
        };
      });
  } catch (error) {
    return {
      status: 401,
      message: "Something Went Wrong.",
      error: error.message,
    };
  }
};

const getCompanyData = async (req, res) => {
  try {
    const cid = req.params.cid;
    return await models.companyModel
      .findOne({
        attributes: ["id", "company_name", "location", "founded_on", "company_logo"],
        where: { id: cid },
      })
      .then(async (companyData) => {
        if (companyData) {
          return {
            status: 200,
            message: "Company Data.",
            data: companyData,
          };
        } else {
          return {
            status: 400,
            message: "Data not found",
            data: [],
          };
        }
      })
      .catch((error) => {
        return {
          status: 401,
          message: "Something Went Wrong.",
          error: error.message,
        };
      });
  } catch (error) {
    return {
      status: 401,
      message: "Something Went Wrong.",
      error: error.message,
    };
  }
};


const getCompanyReviews = async (req, res) => {
  try {
    const cid = req.params.cid;
    console.log('cid: ', cid);
    return await models.companyReviewModel
      .findAll({
        attributes: ["id", "cid", "full_name", "subject", "review_content", "rating", "create_ts"],
        where: { cid },
      },)
      .then(async (companyReviews) => {
        return {
          status: 200,
          message: "Company Reviews.",
          data: companyReviews,
        };
      })
      .catch((error) => {
        return {
          status: 401,
          message: "Something Went Wrong.",
          error: error.message,
        };
      });
  } catch (error) {
    return {
      status: 401,
      message: "Something Went Wrong.",
      error: error.message,
    };
  }
};

const addReviews = async (req, res) => {
  try {
    let data = req.body;
    console.log('data: ', data);
    return await models.companyReviewModel.create({
      full_name: data?.fullName,
      subject: data?.subject,
      review_content: data?.reviewText,
      rating: data?.rating,
      cid: data?.cid,
    }).then(async (result) => {
      return {
        status: 200,
        message: "Review added successfully",
        data: result,
      };
    })
      .catch((error) => {
        return {
          status: 401,
          message: "Something Went Wrong.",
          error: error.message,
        };
      });
  } catch (error) {
    return {
      status: 401,
      message: "Something Went Wrong.",
      error: error.message,
    };
  }
};


const login = async (req, res) => {
  try {
    const {userName, password} = req.body;
    return await models.userModel
      .findOne({
        attributes: ["id", "user_name", "user_image"],
        where: { userName: cid },
      })
      .then(async (companyData) => {
        if (companyData) {
          return {
            status: 200,
            message: "Company Data.",
            data: companyData,
          };
        } else {
          return {
            status: 400,
            message: "Data not found",
            data: [],
          };
        }
      })
      .catch((error) => {
        return {
          status: 401,
          message: "Something Went Wrong.",
          error: error.message,
        };
      });
  } catch (error) {
    return {
      status: 401,
      message: "Something Went Wrong.",
      error: error.message,
    };
  }
};

module.exports = {
  addCompany,
  getCompanyList,
  getCompanyReviews,
  getCompanyData,
  addReviews,
  signUp,
  login
};
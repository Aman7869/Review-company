const app = require("express").Router();
const companyMainServices = require("../services/companyMainServices");


app.post("/add-company", async (req, res) => {
  try {
    const response = await companyMainServices.addCompany(req, res);
    res.send(response);
  } catch (error) {
    res.send(error);
  }
});

app.post("/sign-up", async (req, res) => {
  try {
    const response = await companyMainServices.signUp(req, res);
    res.send(response);
  } catch (error) {
    res.send(error);
  }
});

app.post("/login", async (req, res) => {
  try {
    const response = await companyMainServices.login(req, res);
    res.send(response);
  } catch (error) {
    res.send(error);
  }
});

app.post("/add-reviews", async (req, res) => {
  try {
    const response = await companyMainServices.addReviews(req, res);
    res.send(response);
  } catch (error) {
    res.send(error);
  }
});

app.get("/get-company-listing", async (req, res) => {
  try {
    const response = await companyMainServices.getCompanyList(req, res);
    res.send(response);
  } catch (error) {
    res.send(error);
  }
});

app.get("/get-company-data/:cid", async (req, res) => {
  try {
    const response = await companyMainServices.getCompanyData(req, res);
    res.send(response);
  } catch (error) {
    res.send(error);
  }
});

app.get("/get-company-reviews/:cid", async (req, res) => {
  try {
    const response = await companyMainServices.getCompanyReviews(req, res);
    res.send(response);
  } catch (error) {
    res.send(error);
  }
});

module.exports = app;
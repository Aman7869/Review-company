'use strict';
const Sequelize = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    const userModel = sequelize.define('userModel',
        {
            id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                autoIncrement: true,
                primaryKey: true
            },
            user_name: DataTypes.STRING,
            dob: DataTypes.STRING,
            phoneNumber: DataTypes.STRING,
            city: DataTypes.STRING,
            user_image: DataTypes.STRING,
            create_ts: {
                type: 'TIMESTAMP',
                defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
                allowNull: false
            }
        },
        {
            freezeTableName: true,
            tableName: 'tbl_users',
            updatedAt: false,
            createdAt: false,
        }
    );
    return userModel;
}

'use strict';
const Sequelize = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    const companyModel = sequelize.define('companyModel',
        {
            id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                autoIncrement: true,
                primaryKey: true
            },
            company_name: DataTypes.STRING,
            location: DataTypes.STRING,
            founded_on: DataTypes.STRING,
            company_logo: DataTypes.STRING,
            city: DataTypes.STRING,
            create_ts: {
                type: 'TIMESTAMP',
                defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
                allowNull: false
            }
        },
        {
            freezeTableName: true,
            tableName: 'tbl_company',
            updatedAt: false,
            createdAt: false,
        }
    );
    return companyModel;
}

'use strict';
const Sequelize = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    const companyReviewModel = sequelize.define('companyReviewModel',
        {
            id: {
                type: DataTypes.INTEGER,
                allowNull: false,
                autoIncrement: true,
                primaryKey: true
            },
            cid: DataTypes.INTEGER,
            full_name: DataTypes.STRING,
            subject: DataTypes.STRING,
            review_content: DataTypes.STRING,
            rating: DataTypes.INTEGER,
            create_ts: {
                type: 'TIMESTAMP',
                defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
                allowNull: false
            },
        },
        {
            freezeTableName: true,
            tableName: 'tbl_company_reviews',
            updatedAt: false,
            createdAt: false,
        }
    );
    return companyReviewModel;
}

//admin
const companyRoute = require("express").Router();
//front
const mainRoute = require("./routes/companyRoutes");

//front
companyRoute.use(mainRoute);

module.exports = companyRoute;
